//
//  NFConstants.h
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/12/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#define FIRST_SINGIN @"firstSingin"
#define LOGIN_STATUS @"loginStatus"
