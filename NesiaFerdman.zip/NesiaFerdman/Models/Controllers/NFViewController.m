//
//  NFViewController.m
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/13/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import "NFViewController.h"

@interface NFViewController ()

@end

@implementation NFViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.title = @"Календарь";
//    NSArray *itemArray = [NSArray arrayWithObjects: @"День", @"Неделя", @"Месяц", nil];
//    self.segmentedControl = [[NFSegmentedControl alloc] initWithItems:itemArray];
//    _segmentedControl.frame = CGRectMake(0, 0, self.view.frame.size.width - 30, 34);
//    _segmentedControl.selectedSegmentIndex = 0;
//    [self.navigationController.navigationBar addSubview:_segmentedControl];
//    _segmentedControl.center = self.navigationController.navigationBar.center;
//    [_segmentedControl addTarget:self action:@selector(pressSegment:) forControlEvents:UIControlEventValueChanged];
//    
//    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addButtonAction)];
//    addButton.tintColor = [UIColor whiteColor];
//    self.navigationItem.rightBarButtonItem = addButton;
//
}

//- (void)addButtonAction {
//    NSLog(@"add button pressed from %@", NSStringFromClass([self class]));
//}
////
//- (IBAction)pressSegment:(NFSegmentedControl *)sender {
//    NSLog(@"press segment at index %ld", sender.selectedSegmentIndex);
//}

@end

/*
 [YourSegment addTarget:self action:@selector(segmentAction:) forControlEvents:UIControlEventValueChanged];
 
 - (IBAction)segmentAction:(UISegmentedControl *)sender
 {
 NSString * theTitle = [sender titleForSegmentAtIndex:sender.selectedSegmentIndex]
 }
 */
