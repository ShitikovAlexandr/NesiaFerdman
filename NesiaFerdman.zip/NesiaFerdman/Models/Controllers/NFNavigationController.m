//
//  NFNavigationController.m
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/12/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import "NFNavigationController.h"
#import "NFNavigationBar.h"

@interface NFNavigationController ()

@end

@implementation NFNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    //NFNavigationBar *customNavBar = [[NFNavigationBar alloc] init];
}

@end
