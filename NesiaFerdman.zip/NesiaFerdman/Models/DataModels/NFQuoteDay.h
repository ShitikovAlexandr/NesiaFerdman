//
//  NFQuoteDay.h
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/12/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NFQuoteDay : NSObject
@property (strong, nonatomic) NSString *quote;
@property (strong, nonatomic) NSString *autor;

- (id)initTestData;

@end
