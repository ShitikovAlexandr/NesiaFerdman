//
//  NFWeekDateModel.m
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/20/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import "NFWeekDateModel.h"

@implementation NFWeekDateModel


- (void)getDescription {
    NSLog(@"start - > %@, end -> %@", self.startOfWeek, self.endOfWeek);
    for (NSData *dat in self.allDateOfWeek) {
        NSLog(@"content date - > %@", dat);
    }
}

@end
