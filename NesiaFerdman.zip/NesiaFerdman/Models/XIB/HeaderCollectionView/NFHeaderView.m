//
//  NFHeaderView.m
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/14/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import "NFHeaderView.h"
#import "NFHeaderCell.h"
#import "NFWeekDateModel.h"

@interface NFHeaderView()
@property (strong, nonatomic) NFDateModel *dateSourse;
@property (assign, nonatomic) NSInteger currentIndex;
@end

#define HEADER_NOTIF  @"kHederChange"
@implementation NFHeaderView

- (void)addNFDateModel:(NFDateModel *)model weeks:(BOOL)weeks {
    
    self.sourseArray = [NSMutableArray array];
    self.displayWeeks = weeks;
    self.dateSourse = model;
    [self setDataToSourse];
}

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.collectionView.frame.size.width/4, self.collectionView.frame.size.height)];
    leftView.backgroundColor = self.collectionView.backgroundColor;
    leftView.alpha = 0.6;
    leftView.userInteractionEnabled = false;
    [self addSubview:leftView];
    
    UIView *righttView = [[UIView alloc] initWithFrame:CGRectMake(self.collectionView.frame.size.width - self.collectionView.frame.size.width/4, 0, self.collectionView.frame.size.width/3, self.collectionView.frame.size.height)];
    righttView.backgroundColor = self.collectionView.backgroundColor;
    righttView.alpha = 0.6;
    righttView.userInteractionEnabled = false;
    [self addSubview:righttView];
    
    NSIndexPath *centerCellIndexPath =
    [self.collectionView indexPathForItemAtPoint:
     [self convertPoint:[self.collectionView center] toView:self.collectionView]];
    [self.collectionView scrollToItemAtIndexPath:centerCellIndexPath
                                atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally
                                        animated:true];
    self.currentIndex = centerCellIndexPath.item;
    
    
}

- (instancetype) initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
        [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
        
        self.collectionView = [[UICollectionView alloc] initWithFrame:self.frame collectionViewLayout:flowLayout];
        [self setUpConstraints];
        self.collectionView.collectionViewLayout = flowLayout;
        self.collectionView.delegate = self;
        self.collectionView.dataSource = self;
        self.collectionView.showsVerticalScrollIndicator = NO;
        self.collectionView.showsHorizontalScrollIndicator = NO;
        self.collectionView.backgroundColor = [UIColor colorWithRed:240/255.0 green:239/255.0 blue:245/255.0 alpha:1];
        [self addSubview:self.collectionView];
        
        self.layer.shadowColor = [UIColor blackColor].CGColor;
        self.layer.shadowOffset = CGSizeMake(0.f, 1.f);
        self.layer.shadowRadius = 0.f;
        self.layer.shadowOpacity = 1.f;
        
        [self.collectionView registerNib:[UINib nibWithNibName:@"NFHeaderCell" bundle:nil] forCellWithReuseIdentifier:@"NFHeaderCell"];
        self.sourseArray = [NSMutableArray array];
        
    }
    return self;
}

- (void)setUpConstraints {
    
    self.collectionView.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:self.collectionView];
    
    NSArray<NSLayoutConstraint *> *constraints = @[
                                                   [NSLayoutConstraint constraintWithItem:self attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.collectionView attribute:NSLayoutAttributeTop multiplier:1 constant:0],
                                                   [NSLayoutConstraint constraintWithItem:self attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.collectionView attribute:NSLayoutAttributeBottom multiplier:1 constant:1],
                                                   [NSLayoutConstraint constraintWithItem:self attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self.collectionView attribute:NSLayoutAttributeLeading multiplier:1 constant:0],
                                                   [NSLayoutConstraint constraintWithItem:self attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:self.collectionView attribute:NSLayoutAttributeTrailing multiplier:1 constant:0]
                                                   ];
    [self addConstraints:constraints];
}

//- (void) setStartDate:(NSDate *)fromDate endDate:(NSDate *)toDate displayWeeks:(BOOL)week {
//    self.fromDate = fromDate;
//    self.toDate = toDate;
//    self.displayWeeks = week;
//    self.sourseArray = [self addDateToArray];
//    [self.collectionView reloadData];
//}

- (void)addDataToArray:(NSArray *)array {
    [self.sourseArray arrayByAddingObjectsFromArray:array];
    [self.collectionView reloadData];
}

#pragma mark - UICollectionViewDataSource -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.sourseArray.count;
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    NFHeaderCell *cell = [self.collectionView dequeueReusableCellWithReuseIdentifier:@"NFHeaderCell" forIndexPath:indexPath];
    NSString *title = [self.sourseArray objectAtIndex:indexPath.item];
    cell.titleDateLabel.text = title;
    return cell;
}


#pragma mark - UICollectionViewDelegateFlowLayout -

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    return CGSizeMake(self.collectionView.frame.size.width/2.2 , self.collectionView.frame.size.height);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    [collectionView scrollToItemAtIndexPath:indexPath
                           atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally
                                   animated:true];
    
    
    self.selectedIndex = indexPath.item;
    if (self.selectedIndex != self.currentIndex) {
        self.currentIndex = self.selectedIndex ;
        NSNotification *notification = [NSNotification notificationWithName:HEADER_NOTIF object:self];
        [[NSNotificationCenter defaultCenter]postNotification:notification];
    }
    
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    NSLog(@"end scroll");
    NSIndexPath *centerCellIndexPath =
    [self.collectionView indexPathForItemAtPoint:
     [self convertPoint:[self.collectionView center] toView:self.collectionView]];
    [self.collectionView scrollToItemAtIndexPath:centerCellIndexPath
                                atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally
                                        animated:true];
    self.selectedIndex = centerCellIndexPath.item;
    if (self.selectedIndex != self.currentIndex) {
        self.currentIndex = self.selectedIndex ;
        NSNotification *notification = [NSNotification notificationWithName:HEADER_NOTIF object:self];
        [[NSNotificationCenter defaultCenter]postNotification:notification];
    }
    
    
}


- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    NSLog(@"end druggin");
    NSIndexPath *centerCellIndexPath =
    [self.collectionView indexPathForItemAtPoint:
     [self convertPoint:[self.collectionView center] toView:self.collectionView]];
    [self.collectionView scrollToItemAtIndexPath:centerCellIndexPath
                                atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally
                                        animated:true];
    self.selectedIndex = centerCellIndexPath.item;
    if (self.selectedIndex != self.currentIndex) {
        self.currentIndex = self.selectedIndex;
        NSNotification *notification = [NSNotification notificationWithName:HEADER_NOTIF object:self];
        [[NSNotificationCenter defaultCenter]postNotification:notification];
    }
    
    
}

//- (NSMutableArray *)addDateToArray {
//
//    if (!self.displayWeeks) {
//        NSMutableArray *dateList = [NSMutableArray array];
//        NSCalendar *currentCalendar = [NSCalendar currentCalendar];
//        NSDateComponents *comps = [[NSDateComponents alloc] init];
//        [comps setDay:1];
//        [dateList addObject: self.fromDate];
//        NSDate *currentDate = self.fromDate;
//        currentDate = [currentCalendar dateByAddingComponents:comps toDate:currentDate  options:0];
//        while ( [self.toDate compare: currentDate] != NSOrderedAscending) {
//            [dateList addObject: currentDate];
//            currentDate = [currentCalendar dateByAddingComponents:comps toDate:currentDate  options:0];
//        }
//        return dateList;
//
//    } else {
//
//        NSCalendar *cal = [NSCalendar currentCalendar];
//        NSDate *now = [NSDate date];
//        NSDate *startOfTheWeek;
//        NSDate *endOfWeek;
//        NSTimeInterval interval;
//        [cal rangeOfUnit:NSCalendarUnitWeekOfMonth
//               startDate:&startOfTheWeek
//                interval:&interval
//                 forDate:now];
//        //startOfWeek holds now the first day of the week, according to locale (monday vs. sunday)
//
//        endOfWeek = [startOfTheWeek dateByAddingTimeInterval:interval-1];
//        // holds 23:59:59 of last day in week.
//        NSLog(@"start date -> %@, end date %@", startOfTheWeek, endOfWeek);
//
//
//        return [NSMutableArray arrayWithObjects:@"testWeek1", @"testWeek2", @"testWeek3", @"testWeek4", nil];
//    }
//}

- (NSString *)dateToString:(NSDate *)date {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    return [dateFormatter stringFromDate:date];
}

- (void)setDataToSourse {
    if (self.displayWeeks) {
        
        for (NFWeekDateModel *week in self.dateSourse.weekArray) {
            NSString *titleWeek = [NSString stringWithFormat:@"%@-%@", [self dateToString:week.startOfWeek], [self dateToString:week.endOfWeek]];
            [self.sourseArray addObject:titleWeek];
        }
    } else {
        for (NSDate *dat in self.dateSourse.fromToDateArray) {
            NSString *dayTitle = [self dateToString:dat];
            [self.sourseArray addObject:dayTitle];
        }
    }
    [self.collectionView reloadData];
}

#pragma mark - NFHeaderViewProtocol

- (void)reselectDate {
    // NSLog(@"headar change from class %@",NSStringFromClass([self class]));
}


@end
