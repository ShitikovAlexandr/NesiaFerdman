//
//  NFDayTableViewCell.m
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/18/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import "NFDayTableViewCell.h"

@interface NFDayTableViewCell()
@property (assign, nonatomic) CGFloat offsetY;
@property (assign, nonatomic) BOOL isCurrentTime;
@property (assign, nonatomic) BOOL isSecondCall;
@end


@implementation NFDayTableViewCell

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    self.circleRadius = 25.f;
    self.offsetX = 12.f;
    self.timeLabel.frame = CGRectMake(self.offsetX, self.frame.size.height/2.f - self.circleRadius, self.circleRadius*2, self.circleRadius*2);
    
    self.offsetY = self.frame.size.height/2.f - self.circleRadius;
    self.circleLayer = [CAShapeLayer layer];
    [self.circleLayer setPath:[[UIBezierPath bezierPathWithOvalInRect:CGRectMake(self.offsetX, _offsetY, self.circleRadius*2, self.circleRadius*2)] CGPath]];
    [self.circleLayer setFillColor:[[UIColor colorWithRed:238/255.0 green:239/255.0 blue:241/255.0 alpha:1] CGColor]];
    self.layer.masksToBounds = YES;
    [self.layer addSublayer:self.circleLayer];
    [self.layer insertSublayer:_timeLabel.layer atIndex:(int)[self.layer.sublayers count]];
    
    if (_isCurrentTime) {
        [self addTimeLine];
    }
    
}

- (void)addTimeLine {
    CGPoint starPoint = CGPointMake(self.offsetX + self.circleRadius*2.f,self.offsetY + self.circleRadius);
    CGFloat diametrOfTimeLinrPoint = 10.f;
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(starPoint.x + diametrOfTimeLinrPoint/2, starPoint.y)];
    [path addLineToPoint:CGPointMake(self.frame.size.width, self.offsetY + self.circleRadius)];
    self.timeLineLayer = [CAShapeLayer layer];
    self.timeLineLayer.path = [path CGPath];
    self.timeLineLayer.strokeColor = [[UIColor colorWithRed:83/255.0 green:220/255.0 blue:91/255.0 alpha:1] CGColor];
    self.timeLineLayer.lineWidth = 1.0;
    [self.layer addSublayer:self.timeLineLayer];
    
    self.circleLayerTineLine = [CAShapeLayer layer];
    [self.circleLayerTineLine setBounds:CGRectMake(starPoint.x, starPoint.y,diametrOfTimeLinrPoint-2.0f, diametrOfTimeLinrPoint-2.0f)];
    [self.circleLayerTineLine setPosition:starPoint];
    UIBezierPath *pathCircle = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(starPoint.x, starPoint.y,diametrOfTimeLinrPoint-2.0f, diametrOfTimeLinrPoint-2.0f)];
    [self.circleLayerTineLine setPath:[pathCircle CGPath]];
    [self.circleLayerTineLine setFillColor:[UIColor clearColor].CGColor];
    [self.circleLayerTineLine setStrokeColor:[UIColor colorWithRed:83/255.0 green:220/255.0 blue:91/255.0 alpha:1].CGColor];
    [self.circleLayerTineLine setLineWidth:diametrOfTimeLinrPoint * 0.25];
    [self.layer addSublayer:self.circleLayerTineLine];
}

- (void)removeTimeLine {
    [self.timeLineLayer removeFromSuperlayer];
}

- (void) addTimeLineWithIndexPath:(NSIndexPath *)index {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"H"];
    //[dateFormatter stringFromDate:date];
    NSString *time = [NSString stringWithFormat:@"%ld", (long)index.row];
    if ([time isEqualToString:[dateFormatter stringFromDate:[NSDate date]]]) {
        self.isCurrentTime = true;
    }
}

- (void) prepareForReuse {
    self.isCurrentTime = false;
    [self.circleLayer removeFromSuperlayer];
    [self.timeLineLayer removeFromSuperlayer];
    [self.circleLayerTineLine removeFromSuperlayer];
    [self setNeedsDisplay];
}

@end
