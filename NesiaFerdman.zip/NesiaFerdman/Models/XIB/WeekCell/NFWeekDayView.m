//
//  NFWeekDayView.m
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/20/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#define LINE_COLOR [UIColor colorWithRed:238/255.0 green:239/255.0 blue:241/255.0 alpha:1]
#define TASK_CIRCLE_COLOR [UIColor colorWithRed:56/255.0 green:86/255.0 blue:237/255.0 alpha:1]


#import "NFWeekDayView.h"

@implementation NFWeekDayView



- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    self.layer.masksToBounds = YES;
    CGPoint startPoint = CGPointMake(CGRectGetWidth(self.frame)/2, 0);
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:startPoint];
    [path addLineToPoint:CGPointMake(startPoint.x, CGRectGetHeight(self.frame))];
    CAShapeLayer *centerLine = [CAShapeLayer layer];
    centerLine.path = [path CGPath];
    centerLine.strokeColor = [UIColor colorWithRed:238/255.0 green:239/255.0 blue:241/255.0 alpha:1].CGColor;
    centerLine.lineWidth = 1.0;
    [self.layer addSublayer:centerLine];
}

- (void)addTaskButtonWithIndexPath:(NSIndexPath *)index {
    [self addTaskCircle];
}

- (void)addTaskCircle {
    CGPoint starPoint = CGPointMake(self.bounds.size.width/2, self.bounds.size.height/2);
    CGFloat diametrOfTimeLinrPoint = 10.f;
    NSLog(@"start point %f", starPoint.x);
    
    self.circleLayer = [[CAShapeLayer alloc] init];
    [self.circleLayer setBounds:CGRectMake(starPoint.x, starPoint.y,diametrOfTimeLinrPoint-2.0f, diametrOfTimeLinrPoint-2.0f)];
    [self.circleLayer setPosition:starPoint];
    UIBezierPath *pathCircle = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(starPoint.x, starPoint.y,diametrOfTimeLinrPoint-2.0f, diametrOfTimeLinrPoint-2.0f)];
    [self.circleLayer setPath:[pathCircle CGPath]];
    [self.circleLayer setFillColor:[UIColor clearColor].CGColor];
    [self.circleLayer setStrokeColor:TASK_CIRCLE_COLOR.CGColor];
    [self.circleLayer setLineWidth:diametrOfTimeLinrPoint * 0.3];
    [self.layer addSublayer:self.circleLayer];
}

@end
