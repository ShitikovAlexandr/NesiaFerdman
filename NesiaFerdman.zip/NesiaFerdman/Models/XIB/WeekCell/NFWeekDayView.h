//
//  NFWeekDayView.h
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/20/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NFWeekDayView : UIView
@property (strong, nonatomic) CAShapeLayer *circleLayer;

- (void)addTaskButtonWithIndexPath:(NSIndexPath *)index;

@end
