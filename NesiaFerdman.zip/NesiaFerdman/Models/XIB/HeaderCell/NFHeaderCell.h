//
//  NFHeaderCell.h
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/14/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NFHeaderCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleDateLabel;

@end
