//
//  NFHeaderCell.m
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/14/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import "NFHeaderCell.h"

@implementation NFHeaderCell

@end
