//
//  NFWeekTaskController.m
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/18/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import "NFWeekTaskController.h"
#import "NFHeaderView.h"
#import "NFWeekTaskCell.h"
#import "NFWeekDayView.h"

@interface NFWeekTaskController () <UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet NFHeaderView *header;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@end

@implementation NFWeekTaskController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerNib:[UINib nibWithNibName:@"NFWeekTaskCell" bundle:nil] forCellReuseIdentifier:@"NFWeekTaskCell"];
    NSDate *endDate = [NSDate dateWithTimeIntervalSinceNow:8000000];
    NFDateModel *dateLimits = [[NFDateModel alloc] initWithStartDate:[NSDate date] endDate:endDate];
    [self.header addNFDateModel:dateLimits weeks:YES];
}

#pragma mark - UITableViewDataSource -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 24;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NFWeekTaskCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NFWeekTaskCell"];
    cell.timeLabel.text = [NSString stringWithFormat:@"%02ld", (long)indexPath.row];
    if (indexPath.row == 17) {
        for (NFWeekDayView *view in cell.dayViewArray) {
            if (view.tag == 3) {
                [view addTaskButtonWithIndexPath:indexPath];
            }
        }
    }
    return cell;
}

#pragma mark - UITableViewDelegate -

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}


@end
