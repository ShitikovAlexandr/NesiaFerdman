//
//  NFDayTaskController.m
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/13/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import "NFDayTaskController.h"
#import "NFHeaderCell.h"
#import "NFHeaderView.h"
#import "NFDayTableViewCell.h"
#import "NFSegmentedControl.h"
#import "NFDateModel.h"
#import "NFWeekDateModel.h"

#define HEADER_NOTIF  @"kHederChange"


@interface NFDayTaskController () <UITableViewDelegate, UITableViewDataSource, NFHeaderViewProtocol>
@property (weak, nonatomic) IBOutlet NFHeaderView *header;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation NFDayTaskController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerNib:[UINib nibWithNibName:@"NFDayTableViewCell" bundle:nil] forCellReuseIdentifier:@"NFDayTableViewCell"];
    
    NSDate *endDate = [NSDate dateWithTimeIntervalSinceNow:8000000];
    NFDateModel *dateLimits = [[NFDateModel alloc] initWithStartDate:[NSDate date] endDate:endDate];
    [self.header addNFDateModel:dateLimits weeks:NO];
    
    // add observer
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reselectDate) name:HEADER_NOTIF object:nil];
    
    
    
    [self setCurrentCellVisible];
}

#pragma mark - UITableViewDataSource -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 24;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NFDayTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NFDayTableViewCell"];
    cell.timeLabel.text = [NSString stringWithFormat:@"%02ld", (long)indexPath.row];
    [cell addTimeLineWithIndexPath:indexPath];
    return cell;
}

#pragma mark - UITableViewDelegate -

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 65;
}

#pragma mark - Helpers -

- (void)setCurrentCellVisible {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"H"];
    NSInteger row =  [[dateFormatter stringFromDate:[NSDate date]] integerValue];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:0];
    [self.tableView scrollToRowAtIndexPath:indexPath
                          atScrollPosition:UITableViewScrollPositionTop
                                  animated:YES];
}

- (void)reselectDate {
    NSLog(@"headar change from class %ld",(long)self.header.selectedIndex);
}


@end
