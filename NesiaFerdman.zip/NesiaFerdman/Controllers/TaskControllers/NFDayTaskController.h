//
//  NFDayTaskController.h
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/13/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import "NFViewController.h"

@interface NFDayTaskController : NFViewController

@end
