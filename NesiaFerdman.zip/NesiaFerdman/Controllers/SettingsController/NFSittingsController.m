//
//  NFSittingsController.m
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/21/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import "NFSittingsController.h"
#import "NFGoogleManager.h"

@interface NFSittingsController ()
@property (weak, nonatomic) IBOutlet UIButton *exitButton;

@end

@implementation NFSittingsController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.exitButton addTarget:self action:@selector(exitAction) forControlEvents:UIControlEventTouchDown];
}

- (void)exitAction {
    [[NFGoogleManager sharedManager] logOutWithTarget:self];
}


@end
