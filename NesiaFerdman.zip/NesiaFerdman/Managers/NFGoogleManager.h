//
//  NFGoogleManager.h
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/12/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GTMOAuth2ViewControllerTouch.h"
#import "GTLCalendar.h"

@interface NFGoogleManager : NSObject

@property (strong, nonatomic) NSMutableArray *eventArray;
@property (strong, nonatomic) GTLServiceCalendar *service;


+ (NFGoogleManager *)sharedManager;

- (BOOL)isLoginWithTarget:(id)target;
- (void)loginWithGoogleWithTarget:(UIViewController *)target;
- (void)logOutWithTarget:(id)target;
- (void)getUserInfo;

- (void)fetchEventsWithCount:(NSInteger)count minDate:(NSDate *)minDate maxDate:(NSDate *)maxDate;

@end
