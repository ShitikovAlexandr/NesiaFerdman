//
//  NFGoogleManager.m
//  NesiaFerdman
//
//  Created by Alex_Shitikov on 4/12/17.
//  Copyright © 2017 Gemicle. All rights reserved.
//

#import "NFGoogleManager.h"
#import "NFConstants.h"
#import "NFSplashViewController.h"

static NSString *const kKeychainItemName = @"Google Calendar API";
static NSString *const kClientID = @"270949290072-8d4197i3nk6hvk1774a1heghuskugo3m.apps.googleusercontent.com";

//GET https://www.googleapis.com/calendar/v3/calendars/shitikov.net@gmail.com/events?key=270949290072-8d4197i3nk6hvk1774a1heghuskugo3m.apps.googleusercontent.com

@interface NFGoogleManager()
@property (strong, nonatomic) UIViewController *target;
@property (strong, nonatomic) NSString *userId;
@end
@implementation NFGoogleManager
@synthesize service = _service;

+ (NFGoogleManager *)sharedManager {
    static NFGoogleManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[self alloc] init];
        
    });
    return manager;
}

- (BOOL)isLoginWithTarget:(id)target {
    self.target = target;
    self.service = [[GTLServiceCalendar alloc] init];
    self.service.authorizer =
    [GTMOAuth2ViewControllerTouch authForGoogleFromKeychainForName:kKeychainItemName
                                                          clientID:kClientID
                                                      clientSecret:nil];
    
    return !self.service.authorizer.canAuthorize;
}

- (void)loginWithGoogleWithTarget:(UIViewController *)target {
    //Initialize the Google Calendar API service & load existing credentials from the keychain if available.
    self.target = target;
    self.service = [[GTLServiceCalendar alloc] init];
    self.service.authorizer =
    [GTMOAuth2ViewControllerTouch authForGoogleFromKeychainForName:kKeychainItemName
                                                          clientID:kClientID
                                                      clientSecret:nil];
    if (!self.service.authorizer.canAuthorize) {
        // Not yet authorized, request authorization by pushing the login UI onto the UI stack.
        [self.target presentViewController:[self createAuthControllerWithTarget:self.target] animated:YES completion:nil];
    } else {
        //[self fetchEvents];
        NSLog(@"go next from loginWithGoogleWithTarget");
    }
}

- (void)fetchEventsWithCount:(NSInteger)count minDate:(NSDate *)minDate maxDate:(NSDate *)maxDate {
    GTLQueryCalendar *query = [GTLQueryCalendar queryForEventsListWithCalendarId:@"primary"];
    query.maxResults = count;
    query.timeMin = [GTLDateTime dateTimeWithDate:minDate
                                         timeZone:[NSTimeZone localTimeZone]];
    query.timeMax = [GTLDateTime dateTimeWithDate:maxDate
                                         timeZone:[NSTimeZone localTimeZone]];
    query.singleEvents = YES;
    query.orderBy = kGTLCalendarOrderByStartTime;
    
    [self.service executeQuery:query
                      delegate:self
             didFinishSelector:@selector(displayResultWithTicket:finishedWithObject:error:)];
    [self.target dismissViewControllerAnimated:YES completion:nil];
}

// Creates the auth controller for authorizing access to Google Calendar API.
- (GTMOAuth2ViewControllerTouch *)createAuthControllerWithTarget:(UIViewController *)target {
    GTMOAuth2ViewControllerTouch *authController;
    // If modifying these scopes, delete your previously saved credentials by
    // resetting the iOS simulator or uninstall the app.
    NSArray *scopes = [NSArray array];
    //NSArray *scopes = [NSArray arrayWithObjects:kGTLAuthScopeCalendarReadonly, nil];
    authController = [[GTMOAuth2ViewControllerTouch alloc]
                      initWithScope:[scopes componentsJoinedByString:@" "]
                      clientID:kClientID
                      clientSecret:nil
                      keychainItemName:kKeychainItemName
                      delegate:self
                      finishedSelector:@selector(viewController:finishedWithAuth:error:)];
    return authController;
}

- (void)viewController:(GTMOAuth2ViewControllerTouch *)viewController
      finishedWithAuth:(GTMOAuth2Authentication *)authResult
                 error:(NSError *)error {
    if (error != nil) {
        [self showAlert:@"Authentication Error" message:error.localizedDescription WithTarget:self.target];
        self.service.authorizer = nil;
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.target dismissViewControllerAnimated:YES completion:nil];
        });
    }
    else {
        self.service.authorizer = authResult;
        self.userId = [authResult.parameters objectForKey:@"userID"];
        NSLog(@"self.userId ----> %@", self.userId);
        [self.target dismissViewControllerAnimated:YES completion:nil];
    }
}

// Helper for showing an alert
- (void)showAlert:(NSString *)title message:(NSString *)message WithTarget:(UIViewController *)target {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:title
                                        message:message
                                 preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok =
    [UIAlertAction actionWithTitle:@"OK"
                             style:UIAlertActionStyleDefault
                           handler:^(UIAlertAction * action)
     {
         [alert dismissViewControllerAnimated:YES completion:nil];
     }];
    [alert addAction:ok];
    [self.target presentViewController:alert animated:YES completion:nil];
    
}

- (void)logOutWithTarget:(id)target{
    [GTMOAuth2ViewControllerTouch removeAuthFromKeychainForName:kKeychainItemName];
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:
                                @"Main" bundle:[NSBundle mainBundle]];
    NFSplashViewController *splashController = [storyboard instantiateViewControllerWithIdentifier:@"NFSplashViewController"];
    UIViewController *vc = target;
    [vc presentViewController:splashController animated:YES completion:nil];
}

- (void)getUserInfo {
    NSLog(@"User -> %@", self.service.userAgent);
}

- (void)displayResultWithTicket:(GTLServiceTicket *)ticket
             finishedWithObject:(GTLCalendarEvents *)events
                          error:(NSError *)error {
    NSLog(@"events %@", events);
}




@end
